package application.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import application.ClassDetailController.StudentModel;

public class CourseEnrollmentDAO {
    public List<StudentModel> getAllEnrolledStudent(int offeringId, int userDeptId) {
        String sql = """
                                       SELECT
                    s.student_id,
                    s.roll_no,
                    s.full_name,
                    sci.email_address,
                    COALESCE(
                        ROUND(
                            (
                                COUNT(DISTINCT cs.session_id) - COUNT(DISTINCT a.attendance_id)
                            ) * 100.0 / NULLIF(
                                COUNT(DISTINCT cs.session_id),
                                0
                            ),
                            2
                        ),
                        0.00
                    ) AS attendance_percentage,
                    s.gpa
                FROM
                    student s
                    LEFT JOIN student_contact_information sci ON s.student_id = sci.student_id
                    JOIN course_enrollment ce ON s.student_id = ce.student_id
                    AND ce.status = 'ENROLLED'
                    JOIN course_offering co ON ce.offering_id = co.offering_id
                    JOIN course c ON co.course_id = c.course_id
                    LEFT JOIN class_session cs ON cs.offering_id = co.offering_id
                    AND cs.is_cancelled = FALSE
                    LEFT JOIN attendance a ON cs.session_id = a.session_id
                    AND ce.enrollment_id = a.enrollment_id
                WHERE
                    co.offering_id = ?
                    AND (
                        c.dept_id = ?
                        OR s.dept_id = ?
                    )
                GROUP BY
                    s.student_id,
                    s.roll_no,
                    s.full_name,
                    sci.email_address,
                    s.gpa
                ORDER BY s.roll_no ASC;
                                        """;
        List<StudentModel> activeStudents = new ArrayList<>();
        try (Connection conn = DatabaseConnector.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, offeringId);
            pstmt.setInt(2, userDeptId);
            pstmt.setInt(3, userDeptId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    int studentId = rs.getInt("student_id");
                    String rollNum = rs.getString("roll_no");
                    String name = rs.getString("full_name");
                    String emailAddress = rs.getString("email_address");
                    BigDecimal attendanceBd = rs.getBigDecimal("attendance_percentage");
                    int attendancePercentage = (attendanceBd != null) ? attendanceBd.intValue() : 0;
                    BigDecimal gpaDecimal = rs.getBigDecimal("gpa");
                    double gpa = (gpaDecimal != null) ? gpaDecimal.doubleValue() : 0.0;
                    activeStudents
                            .add(new StudentModel(String.valueOf(studentId), rollNum, name, emailAddress,
                                    attendancePercentage, gpa));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return activeStudents;
    }

    public int removeStudentFromClass(int studentId, int offeringId) {
        String sql = """
                UPDATE course_enrollment
                SET
                    status = 'DROPPED'
                WHERE
                    student_id = ?
                    AND offering_id = ?;
                        """;
        try (Connection conn = DatabaseConnector.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, studentId);
            pstmt.setInt(2, offeringId);
            return pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
}
